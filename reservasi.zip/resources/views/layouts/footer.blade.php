<footer>
    <div class="row">
        <div>
            <h4 class="text-center">Copyright &copy; Laboratorium Pemrograman 2 2018 Informatika ITS 2018<br><img src="../img/its-perisai-biru.png" style="height:28px;"> <img src="../img/if.png" style="height:28px;"> <img src="../img/lp2.png" style="height:28px;"></h4>
        </div>
    </div>
</footer>