<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/admin/index">Admin</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li>
                    <a href="/logout"><strong>LOG OUT</strong></a>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li id="beranda">
                        <a href="/admin/index">Beranda</a>
                    </li>
                    <li id="agenda">
                        <a href="/admin/agenda">Post Agenda Jurusan</a>
                    </li>
                    <li id="listagenda">
                        <a href="/admin/listagenda">Edit Agenda Jurusan</a>
                    </li>
                    <li id="acc">
                        <a href="/admin/accruangan">Permintaan Peminjaman Ruangan</a>
                    </li>
                    <li id="editpinjam">
                        <a href="/admin/editpeminjaman">Sunting Peminjaman Ruangan</a>
                    </li>
                    <li id="tambahdosen">
                        <a href="/admin/tambahdosen">Tambah Data Dosen</a>
                    </li>
                    <li id="setelan">
                        <a href="/admin/setelan">Setelan</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->