
<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts.userHead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <div class="container">
        <p>Yth. <?php echo e($data['nama_permohonan']); ?>,</p>
        <p>Maaf, reservasi dengan kode <?php echo e($data['kode_permohonan']); ?> tidak dapat kami setujui.</p>
        <p>Berikut adalah rincian permohonan anda: </p>
        <br>
        <p>Nama Kegiatan : <?php echo e($data['nama_kegiatan']); ?></p>
        <p>Tanggal : <?php echo e($data['tanggal']); ?></p>
        <p>Waktu Mulai : <?php echo e($data['waktu_mulai']); ?></p>
        <p>Waktu Selesai : <?php echo e($data['waktu_selesai']); ?></p>
        <br>
        <br><p>Silahkan hubungi kami atau reservasi kembali dengan jadwal lain.</p>
        <br><p>Terima kasih, <br> Laboratorium Pemrograman 2</p>
    </div>        
</body>
</html>