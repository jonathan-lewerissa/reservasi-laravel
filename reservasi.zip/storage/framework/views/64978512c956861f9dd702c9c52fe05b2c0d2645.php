<?php if(isset($calendarEvent)): ?>
    <form action="<?php echo e($action); ?>" method="POST">
        <input type="hidden" name="_method" value="PUT" />
<?php else: ?>
    <form action="<?php echo e($action); ?>" method="POST">
<?php endif; ?>
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

    <?php /* Title field */ ?>
    <label for="title">*<?php echo trans('calendar-events::calendar-events.title'); ?></label>
    <input
            name="title"
            type="text"
            placeholder="<?php echo trans('calendar-events::calendar-events.title'); ?>"
            value="<?php echo e(isset($calendarEvent) ? $calendarEvent->title : null); ?>"
    />
    <br />

    <?php /* Description */ ?>
    <label for="description"><?php echo trans('calendar-events::calendar-events.description'); ?></label>
    <textarea
            name="description"
            placeholder="<?php echo trans('calendar-events::calendar-events.your_text_here'); ?>"
            id="description"
    >
        <?php echo e(isset($calendarEvent) ? $calendarEvent->description : null); ?>

    </textarea>
    <br />

    <?php /* All day check box */ ?>
    <label for="all-day">
        <input
                type="checkbox"
                name="all_day"
                value="true"
                id="all-day" onchange="CalendarEvents.allDayToggle();"
                <?php echo e((isset($calendarEvent) && true == $calendarEvent->all_day) ? 'checked=\"\"' : null); ?>

        />
        <?php echo trans('calendar-events::calendar-events.all_day'); ?>

    </label>
    <br />

    <?php /* Start date */ ?>
    <label for="start">*<?php echo trans('calendar-events::calendar-events.start'); ?></label>
    <input
            type="text"
            name="start[date]"
            placeholder="<?php echo trans('calendar-events::calendar-events.date'); ?>"
            id="start"
            value="<?php echo e(isset($calendarEvent) ? date('Y-m-d', strtotime($calendarEvent->start)) : null); ?>"
    />
    -
    <input
            type="text"
            name="start[time]"
            placeholder="<?php echo trans('calendar-events::calendar-events.time'); ?>"
            id="start-time"
            value="<?php echo e(isset($calendarEvent) ? date('H:i:s', strtotime($calendarEvent->start)) : null); ?>"
    />
    <br />

    <?php /* End date */ ?>
    <label for="end"><?php echo trans('calendar-events::calendar-events.end'); ?></label>
    <input
            type="text"
            name="end[date]"
            placeholder="<?php echo trans('calendar-events::calendar-events.end'); ?>"
            id="end"
            value="<?php echo e((isset($calendarEvent) && false == $calendarEvent->all_day) ? strtotime('Y-m-d', $calendarEvent->end) : null); ?>"
    />
    -
    <input
            type="text"
            name="end[time]"
            placeholder="<?php echo trans('calendar-events::calendar-events.time'); ?>"
            id="end-time"
            value="<?php echo e((isset($calendarEvent) && false == $calendarEvent->all_day) ? strtotime('H:i:s', $calendarEvent->end) : null); ?>"
    />
    <br />

    <?php $colors = \Todstoychev\Wsc\Wsc::getColors(); ?>

    <?php /* Border color */ ?>
    <label for="border-color"><?php echo trans('calendar-events::calendar-events.border_color'); ?></label>
    <select name="border_color" id="border-color">
        <option value=""><?php echo trans('calendar-events::calendar-events.select_color'); ?></option>
        <?php foreach($colors as $color): ?>
        <option
                value="#<?php echo e($color); ?>"
                style="background-color: #<?php echo e($color); ?>"
                <?php echo e((isset($calendarEvent) && '#' . $color == $calendarEvent->border_color) ? 'selected=\"\"' : null); ?>

        >
            #<?php echo e($color); ?>

        </option>
        <?php endforeach; ?>
    </select>
    <br />

    <?php /* Background color */ ?>
    <label for="background-color"><?php echo trans('calendar-events::calendar-events.background_color'); ?></label>
    <select name="background_color" id="background-color">
        <option value=""><?php echo trans('calendar-events::calendar-events.select_color'); ?></option>
        <?php foreach($colors as $color): ?>
        <option
                value="#<?php echo e($color); ?>"
                style="background-color: #<?php echo e($color); ?>"
                <?php echo e((isset($calendarEvent) && '#' . $color == $calendarEvent->background_color) ? 'selected=\"\"' : null); ?>

        >
            #<?php echo e($color); ?>

        </option>
        <?php endforeach; ?>
    </select>
    <br />

    <?php /* Text color */ ?>
    <label for="text-color"><?php echo trans('calendar-events::calendar-events.text_color'); ?></label>
    <select name="text_color" id="text-color">
        <option value=""><?php echo trans('calendar-events::calendar-events.select_color'); ?></option>
        <?php foreach($colors as $color): ?>
        <option
                value="#<?php echo e($color); ?>"
                style="background-color: #<?php echo e($color); ?>"
                <?php echo e((isset($calendarEvent) && '#' . $color == $calendarEvent->text_color) ? 'selected=\"\"' : null); ?>

        >
            #<?php echo e($color); ?>

        </option>
        <?php endforeach; ?>
    </select>
    <br />

    <?php /* Reapeat event checkbox */ ?>
    <label for="repeat">
        <input
                type="checkbox"
                name="repeat"
                id="repeat"
                onchange="CalendarEvents.repeatEventToggle();"
                <?php echo e((isset($calendarEvent) && $calendarEvent->calendarEventRepeatDates()->count() > 0) ? 'checked=\"\"' : null); ?>

        />
        <?php echo trans('calendar-events::calendar-events.repeat_event'); ?>

    </label>
    <br />

    <?php /* Repeat events block */ ?>
    <div id="repeat-event">
        <?php echo $__env->make('calendar-events::repeat-dates', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <input type="submit" value="<?php echo trans('calendar-events::calendar-events.save'); ?>" />
</form>
