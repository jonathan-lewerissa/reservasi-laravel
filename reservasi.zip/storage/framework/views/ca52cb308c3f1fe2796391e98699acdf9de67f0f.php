<footer>
    <div class="row">
        <div>
            <p class="text-center">Copyright &copy; Jurusan Teknik Informatika ITS 2016</p>
        </div>
    </div>
</footer>