<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.userHead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script type="text/javascript">
    function validasi(){
        var Tanggal = document.forms["formpinjam"]["tglmulai"].value;
        var date = new Date();
        var tahun = date.getFullYear();
        var bulan = date.getMonth()+1;
        if(bulan<10) bulan='0'+bulan;
        var hari = date.getDate();
        if(hari<10)hari='0'+hari;
        date = tahun+'-'+bulan+'-'+hari;
        if(Tanggal<date){
            alert("Tanggal yang anda pilih telah lewat.")
            return false;
        }
        if(document.forms["formpinjam"]["wktmulai"].value>document.forms["formpinjam"]["wktselesai"].value){
            alert("Waktu mulai dan waktu selesai kegiatan invalid.");
            return false;
        }
        return true;
    }
    </script>
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <?php echo $__env->make('layouts.userNavbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Form Peminjaman Ruangan</h1>
            </div>
        </div>
        <span id="valid"></span>
        <?php if(Session::has('msg')): ?>
            <span style="background-color:red; color:white;">
                <?php echo e(Session::get('msg')); ?>

            </span>
        <?php endif; ?>
        <div class="well">
            <form role="form" onsubmit="return validasi()" name="formpinjam" action="isiPinjam" method="POST">
                <h4>Nama Lengkap:</h4>
                <div class="form-group">
                    <input type="text" name="nama" class="form-control" autocomplete="false" required>
                </div>
                <h4>No. Telepon:</h4>
                <div class="form-group">
                    <input type="text" name="telp" class="form-control" required>
                </div>
                <h4>Email:</h4>
                <div class="form-group">
                    <input type="email" name="email" class="form-control" required>
                </div>
                <h4>Nama Kegiatan:</h4>
                <div class="form-group">
                    <input type="text" name="keg" class="form-control" autocomplete="false" required>
                </div>
                <h4>Tanggal Mulai Kegiatan:</h4>
                <div class="form-group">
                    <input type="date" name="tglmulai" class="form-control" required>
                </div>
                <h4>Waktu Mulai Kegiatan:</h4>
                <div class="form-group">
                    <input type="time" name="wktmulai" class="form-control" required>
                </div>
                <h4>Waktu Selesai Kegiatan:</h4>
                <div class="form-group">
                    <input type="time" name="wktselesai" class="form-control" required>
                </div>
                <h4>Badan Pelaksana Kegiatan:</h4>
                <div class="form-group">
                    <input type="text" name="badan" class="form-control" autocomplete="false" required>
                </div>
                <h4>Ruang yang Ingin Dipinjam:</h4>
                <div class="form-group">
                    <select name="ruang" class="form-control">
                        <?php foreach($ruangan as $ruang): ?>
                        <option value="<?php echo e($ruang->nama_ruangan); ?>"><?php echo e($ruang->nama_ruangan); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <h4>Rutinitas:</h4>
                <div class="form-group">
                    <select name="rutin" class="form-control">
                        <?php foreach($rutinitas as $rutin): ?>
                        <option value="<?php echo e($rutin->frekwensi_rutinitas); ?>"><?php echo e($rutin->keterangan_rutinitas); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <h4>Kali Peminjaman:</h4>
                <div class="form-group">
                    <input type="text" name="kali" class="form-control" required>
                </div>
            <button type="submit" name="pinjam" class="btn btn-primary">Pinjam</button>
            </form>
        </div>


        <hr>

        <!-- Footer -->
        <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </div>
    <!-- /.container -->
    <script type="text/javascript">
    </script>
    <!-- jQuery -->
    <script src="<?php echo e(URL::asset('js/jquery.js')); ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>
</body>

</html>
