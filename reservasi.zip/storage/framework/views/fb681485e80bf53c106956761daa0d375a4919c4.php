<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.userHead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body>
    <?php echo $__env->make('layouts.userNavbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Page Content -->
    <div class="container">
        <!-- Jumbotron Header -->
        <header class="jumbotron hero-spacer">
            <div style="text-align:center;">
                <a href="http://time.is/Surabaya" id="time_is_link" rel="nofollow" style="font-size:64px"></a>
                <span id="Surabaya_z41c" style="font-size:72px"></span>
                <script src="http://widget.time.is/id.js"></script>
                <script>
                time_is_widget.init({Surabaya_z41c:{template:"TIME<br>DATE", date_format:"dayname, dnum monthname year"}});
                </script>
            </div>
        </header>
        <hr>
        <div  id="marquee" direction="up" style="font-size:44px;text-align: center;margin:auto;">
                <ul style="width:100%;">
                <?php foreach($pengumuman as $tulisan): ?>
                    <li><?php echo e($tulisan->info_info); ?></li>
                <?php endforeach; ?>
                </ul>
        </div>
        <!-- Footer -->
        <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="<?php echo e(URL::asset('js/jquery.js')); ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.vticker.min.js')); ?>"></script>
    <script type="text/javascript">
        $(function() {
            $('#marquee').vTicker();
        });
    </script>
</body>

</html>
