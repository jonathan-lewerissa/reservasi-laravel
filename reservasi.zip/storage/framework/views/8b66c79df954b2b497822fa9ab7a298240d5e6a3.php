<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.adminHead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script type="text/javascript">
        function ini(){
            document.getElementById("listagenda").className="active";
        }
    </script>
</head>

<body onload="ini()">

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <?php echo $__env->make('layouts.adminNavbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid" style="height:100%">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Edit Agenda Jurusan</h1>
                    </div>
                </div>
                <!-- /.row -->
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-12">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Tanggal Mulai</th>
                                        <th>Tanggal Selesai</th>
                                        <th>Isi Agenda</th>
                                        <th>Sunting</th>
                                        <th>Hapus</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($lists as $list): ?>
                                    <tr>
                                        <td><?php echo e($list->tanggal_mulai_agenda); ?></td>
                                        <td><?php echo e($list->tanggal_selesai_agenda); ?></td>
                                        <td><?php echo e($list->isi_agenda); ?></td>
                                        <td><a href="editagenda/<?php echo e($list->timestamp_agenda); ?>"><button type="button" class="btn btn-sm btn-info">Sunting</button></a></td>
                                        <td><a href="hapusagenda/<?php echo e($list->timestamp_agenda); ?>"><button type="button" class="btn btn-sm btn-danger">Hapus</button></a></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo e(URL::asset('js/jquery.js')); ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>

    <!-- Morris Charts JavaScript -->
    <script src="<?php echo e(URL::asset('js/plugins/morris/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('js/plugins/morris/morris.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('js/plugins/morris/morris-data.js')); ?>"></script>

</body>

</html>
