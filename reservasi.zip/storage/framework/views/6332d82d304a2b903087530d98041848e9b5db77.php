<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">

<title>SI Peminjaman Ruangan dan Informasi Dosen</title>
<link rel="icon" href="../img/if.png">

<!-- Bootstrap Core CSS -->
<link href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>" rel="stylesheet">

<!-- Custom CSS -->
<link href="<?php echo e(URL::asset('css/heroic-features.css')); ?>" rel="stylesheet">