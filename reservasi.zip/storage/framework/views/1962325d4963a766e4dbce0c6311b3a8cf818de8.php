<html>
<head>
	<title>feed ruangan</title>
<link href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('css/sb-admin.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('css/plugins/morris.css')); ?>" rel="stylesheet">
</head>
<body style="background-color:white">
	now
	<?php if($now!=null): ?>
	<?php echo e($now[0]->nama_kegiatan); ?>

	<?php echo e($now[0]->waktu_mulai_permohonan_peminjaman); ?>

	<?php echo e($now[0]->waktu_selesai_permohonan_peminjaman); ?>

	<?php else: ?>
	kosong
	<?php endif; ?>
	<br>
	next
	<?php if($next!=null): ?>
	<?php echo e($next[0]->nama_kegiatan); ?>

	<?php echo e($next[0]->waktu_mulai_permohonan_peminjaman); ?>

	<?php echo e($next[0]->waktu_selesai_permohonan_peminjaman); ?>

	<?php else: ?>
	kosong
	<?php endif; ?>
</body>
</html>