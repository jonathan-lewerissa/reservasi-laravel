<?php foreach($data as $key): ?> {
	<?php echo e(key); ?>

}