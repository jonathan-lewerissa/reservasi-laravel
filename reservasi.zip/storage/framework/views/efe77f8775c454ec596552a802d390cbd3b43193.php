<form method="post" action="login/admin">
	username<input type="text" name="id">
	password<input type="password" name="pass">
	<button>submit</button>
</form>