<?php

return [
    // Cache expire in minutes
    'cache_ttl' => 10,
];
